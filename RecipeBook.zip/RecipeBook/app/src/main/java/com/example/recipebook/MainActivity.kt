package com.example.recipebook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val picker = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importDb(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) { App(vm) { picker.launch(arrayOf("*/*")) } } }
    }
}

@Composable
fun App(vm: MainViewModel, onPick: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    BackHandler(enabled = vm.selected != null) { vm.close() }
    when {
        vm.needsImport || vm.importedMb >= 0 -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Open your recipe database", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text("Choose the recipes.db file stored on this phone. It is copied into the app once; nothing is uploaded.")
            Spacer(Modifier.height(16.dp))
            if (vm.importedMb >= 0) { CircularProgressIndicator(); Spacer(Modifier.height(8.dp)); Text("Copying… ${vm.importedMb} MB") }
            else Button(onPick) { Text("Choose recipes.db") }
            vm.error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
        vm.error != null && !vm.ready -> Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) { Text(vm.error!!) }
        !vm.ready -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(); Spacer(Modifier.height(12.dp)); Text("Preparing database (first launch only)…")
            }
        }
        vm.selected != null -> DetailScreen(vm)
        else -> Scaffold(bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Search, null) }, label = { Text("Browse") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Favorite, null) }, label = { Text("Saved") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.BarChart, null) }, label = { Text("Overview") })
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().statusBarsPadding()) {
                when (tab) { 0 -> BrowseScreen(vm); 1 -> SavedScreen(vm); else -> OverviewScreen(vm) }
            }
        }
    }
}

@Composable
fun BrowseScreen(vm: MainViewModel) {
    val state = rememberLazyListState()
    val nearEnd by remember { derivedStateOf { val l = state.layoutInfo; (l.visibleItemsInfo.lastOrNull()?.index ?: 0) >= l.totalItemsCount - 5 } }
    LaunchedEffect(nearEnd, vm.items.size) { if (nearEnd) vm.loadMore() }
    Column {
        OutlinedTextField(
            vm.query, vm::onQuery, Modifier.fillMaxWidth().padding(12.dp, 12.dp, 12.dp, 4.dp), singleLine = true,
            placeholder = { Text("Search ${"%,d".format(vm.total)} recipes by name or ingredient") },
            leadingIcon = { Icon(Icons.Default.Search, null) }
        )
        LazyRow(contentPadding = PaddingValues(12.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.countries.take(25)) { (c, n) -> FilterChip(vm.country == c, { vm.onCountry(c) }, { Text("$c · $n") }) }
        }
        if (vm.items.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No recipes match. Try a shorter search.") }
        LazyColumn(state = state, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.items, key = { it.id }) { RecipeRow(it) { vm.open(it.id) } }
        }
    }
}

@Composable
fun RecipeRow(r: Summary, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(r.image, null, Modifier.size(96.dp).background(MaterialTheme.colorScheme.secondaryContainer), contentScale = ContentScale.Crop)
            Column(Modifier.padding(12.dp)) {
                Text(r.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(listOf(r.country, r.time).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun SavedScreen(vm: MainViewModel) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Favorites", style = MaterialTheme.typography.titleLarge) }
        if (vm.favorites.isEmpty()) item { Text("Open a recipe and tap the heart to save it here.") }
        items(vm.favorites, key = { "f" + it.id }) { RecipeRow(it) { vm.open(it.id) } }
        item { Text("Recently viewed", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 12.dp)) }
        items(vm.recent, key = { "r" + it.id }) { RecipeRow(it) { vm.open(it.id) } }
    }
}

@Composable
fun OverviewScreen(vm: MainViewModel) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Inside recipes.db", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${"%,d".format(vm.total)} recipes · ${vm.countries.size} countries · ${vm.languages.size} languages")
        BarCard("By country", vm.countries.take(12))
        BarCard("By language", vm.languages.take(8))
        BarCard("Largest collections", vm.collections.take(8))
    }
}

@Composable
fun BarCard(title: String, rows: List<Pair<String, Int>>) {
    val max = rows.maxOfOrNull { it.second }?.toFloat() ?: 1f
    Card { Column(Modifier.padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium); Spacer(Modifier.height(8.dp))
        rows.forEach { (k, n) ->
            Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(k, Modifier.width(120.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp))) {
                    Box(Modifier.fillMaxWidth(n / max).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                }
                Text("%,d".format(n), Modifier.width(56.dp).padding(start = 8.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: MainViewModel) {
    val r = vm.selected ?: return
    var note by remember(r.id) { mutableStateOf(r.note) }
    Scaffold(topBar = {
        TopAppBar(title = { Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(vm::close) { Icon(Icons.Default.ArrowBack, "Back") } },
            actions = { IconButton(vm::toggleFavorite) {
                Icon(if (r.favorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder, "Favorite")
            } })
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
            AsyncImage(r.image, null, Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(MaterialTheme.colorScheme.secondaryContainer), contentScale = ContentScale.Crop)
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(r.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(listOf(r.country, RecipeDb.formatTime(r.time), r.yield, r.collection).filter { it.isNotBlank() }.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (r.nutrition.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    r.nutrition.forEach { (k, v) -> AssistChip({}, { Text("$k $v") }) }
                }
                Text("Ingredients", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                r.ingredients.forEach { Text("• $it") }
                Text("Steps", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                r.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", Modifier.padding(vertical = 3.dp)) }
                if (r.keywords.isNotBlank()) Text("Keywords: ${r.keywords}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text("My note") })
                Button({ vm.saveNote(note) }) { Text("Save note") }
            }
        }
    }
}
