package com.example.recipebook

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val pageSize = 40
    private var repo: RecipeDb? = null
    private var job: Job? = null

    var ready by mutableStateOf(false); private set
    var needsImport by mutableStateOf(false); private set
    var importedMb by mutableLongStateOf(-1L); private set
    var error by mutableStateOf<String?>(null); private set
    var query by mutableStateOf(""); private set
    var country by mutableStateOf(""); private set
    var total by mutableIntStateOf(0); private set
    var countries by mutableStateOf<List<Pair<String, Int>>>(emptyList()); private set
    var languages by mutableStateOf<List<Pair<String, Int>>>(emptyList()); private set
    var collections by mutableStateOf<List<Pair<String, Int>>>(emptyList()); private set
    var favorites by mutableStateOf<List<Summary>>(emptyList()); private set
    var recent by mutableStateOf<List<Summary>>(emptyList()); private set
    var selected by mutableStateOf<Recipe?>(null); private set
    val items = mutableStateListOf<Summary>()
    var endReached by mutableStateOf(false); private set

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val r = RecipeDb.openIfPresent(getApplication())
                if (r == null) needsImport = true else load(r)
            } catch (e: Exception) { RecipeDb.dbFile(getApplication()).delete(); needsImport = true; error = e.message }
        }
    }

    private suspend fun load(r: RecipeDb) {
        repo = r
        total = r.count(); countries = r.countries(); languages = r.languages(); collections = r.collections()
        favorites = r.favorites(); recent = r.recent()
        needsImport = false; error = null; ready = true
        refresh(debounce = false)
    }

    fun importDb(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                error = null; importedMb = 0
                RecipeDb.importFrom(getApplication(), uri) { importedMb = it shr 20 }
                val r = RecipeDb.openIfPresent(getApplication()) ?: throw IllegalStateException("Import failed")
                r.count() // validates that this is the recipes database
                importedMb = -1
                load(r)
            } catch (e: Exception) {
                RecipeDb.dbFile(getApplication()).delete(); importedMb = -1
                error = "That file could not be used: ${e.message}"
            }
        }
    }

    fun onQuery(q: String) { query = q; refresh() }
    fun onCountry(c: String) { country = if (country == c) "" else c; refresh(debounce = false) }

    private fun refresh(debounce: Boolean = true) {
        job?.cancel()
        job = viewModelScope.launch {
            if (debounce) delay(250)
            val page = withContext(Dispatchers.IO) { repo?.search(query, country, pageSize, 0) } ?: return@launch
            items.clear(); items.addAll(page); endReached = page.size < pageSize
        }
    }

    fun loadMore() {
        if (endReached || job?.isActive == true) return
        job = viewModelScope.launch {
            val page = withContext(Dispatchers.IO) { repo?.search(query, country, pageSize, items.size) } ?: return@launch
            items.addAll(page); endReached = page.size < pageSize
        }
    }

    fun open(id: String) { viewModelScope.launch {
        selected = withContext(Dispatchers.IO) { repo?.get(id) }
        recent = withContext(Dispatchers.IO) { repo?.recent() } ?: recent
    } }
    fun close() { selected = null }

    fun toggleFavorite() {
        val r = selected ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo?.setFavorite(r.id, !r.favorite); favorites = repo?.favorites() ?: favorites }
            selected = r.copy(favorite = !r.favorite)
        }
    }

    fun saveNote(note: String) {
        val r = selected ?: return
        viewModelScope.launch(Dispatchers.IO) { repo?.saveNote(r.id, note) }
        selected = r.copy(note = note)
    }
}
