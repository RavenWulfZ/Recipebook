package com.example.recipebook

import android.content.Context
import android.net.Uri
import java.io.IOException
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Summary(val id: String, val name: String, val country: String, val image: String?, val time: String)
data class Recipe(
    val id: String, val name: String, val country: String, val lang: String, val collection: String,
    val image: String?, val time: String, val yield: String, val categories: List<String>,
    val ingredients: List<String>, val steps: List<String>, val nutrition: Map<String, String>,
    val keywords: String, val favorite: Boolean, val note: String
)

/** Thin wrapper over the bundled recipes.db (copied from assets on first launch). */
class RecipeDb private constructor(private val db: SQLiteDatabase) {

    fun count(): Int = db.rawQuery("SELECT COUNT(*) FROM recipes", null).use { it.moveToFirst(); it.getInt(0) }

    fun countries(): List<Pair<String, Int>> =
        db.rawQuery("SELECT country, COUNT(*) FROM recipes GROUP BY 1 ORDER BY 2 DESC", null).use { c ->
            buildList { while (c.moveToNext()) add(c.getString(0) to c.getInt(1)) }
        }

    fun languages(): List<Pair<String, Int>> =
        db.rawQuery("SELECT lang, COUNT(*) FROM recipes GROUP BY 1 ORDER BY 2 DESC", null).use { c ->
            buildList { while (c.moveToNext()) add(c.getString(0) to c.getInt(1)) }
        }

    fun collections(limit: Int = 10): List<Pair<String, Int>> =
        db.rawQuery("SELECT collection, COUNT(*) FROM recipes GROUP BY 1 ORDER BY 2 DESC LIMIT $limit", null).use { c ->
            buildList { while (c.moveToNext()) add(c.getString(0) to c.getInt(1)) }
        }

    fun search(query: String, country: String, limit: Int, offset: Int): List<Summary> {
        val q = "%${query.trim()}%"
        val sql = """SELECT id,name,country,image,total_time FROM recipes
            WHERE (?1 = '' OR country = ?1)
              AND (?2 = '%%' OR name LIKE ?2 OR keywords LIKE ?2 OR ingredients LIKE ?2)
            ORDER BY name LIMIT $limit OFFSET $offset"""
        return db.rawQuery(sql, arrayOf(country, q)).use(::summaries)
    }

    fun favorites(): List<Summary> = listFrom(
        "SELECT r.id,r.name,r.country,r.image,r.total_time FROM favorites f JOIN recipes r ON r.id=f.recipe_id ORDER BY f.added_at DESC")

    fun recent(): List<Summary> = listFrom(
        "SELECT r.id,r.name,r.country,r.image,r.total_time FROM recent v JOIN recipes r ON r.id=v.recipe_id ORDER BY v.viewed_at DESC LIMIT 30")

    fun get(id: String): Recipe? {
        db.execSQL("INSERT OR REPLACE INTO recent(recipe_id, viewed_at) VALUES(?, datetime('now'))", arrayOf(id))
        db.rawQuery("SELECT * FROM recipes WHERE id=?", arrayOf(id)).use { c ->
            if (!c.moveToFirst()) return null
            fun s(n: String) = c.getString(c.getColumnIndexOrThrow(n)) ?: ""
            val fav = db.rawQuery("SELECT 1 FROM favorites WHERE recipe_id=?", arrayOf(id)).use { it.moveToFirst() }
            val note = db.rawQuery("SELECT note FROM recipe_notes WHERE recipe_id=?", arrayOf(id)).use { if (it.moveToFirst()) it.getString(0) else "" }
            return Recipe(
                id, s("name"), s("country"), s("lang"), s("collection"), s("image").ifBlank { null },
                s("total_time"), s("yield"), strings(s("categories")), strings(s("ingredients")), strings(s("steps")),
                nutrition(s("nutrition")), s("keywords"), fav, note
            )
        }
    }

    fun setFavorite(id: String, on: Boolean) {
        if (on) db.execSQL("INSERT OR IGNORE INTO favorites(recipe_id) VALUES(?)", arrayOf(id))
        else db.execSQL("DELETE FROM favorites WHERE recipe_id=?", arrayOf(id))
    }

    fun saveNote(id: String, note: String) {
        if (note.isBlank()) db.execSQL("DELETE FROM recipe_notes WHERE recipe_id=?", arrayOf(id))
        else db.execSQL("INSERT OR REPLACE INTO recipe_notes(recipe_id,note,updated_at) VALUES(?,?,datetime('now'))", arrayOf(id, note))
    }

    private fun listFrom(sql: String) = db.rawQuery(sql, null).use(::summaries)

    private fun summaries(c: android.database.Cursor) = buildList {
        while (c.moveToNext()) add(Summary(c.getString(0), c.getString(1), c.getString(2), c.getString(3)?.ifBlank { null }, formatTime(c.getString(4))))
    }

    private fun strings(json: String): List<String> = runCatching {
        val a = JSONArray(json); List(a.length()) { a.getString(it).trim() }
    }.getOrDefault(emptyList())

    private fun nutrition(json: String): Map<String, String> = runCatching {
        val o = JSONObject(json); o.keys().asSequence().associateWith { o.getString(it) }
    }.getOrDefault(emptyMap())

    companion object {
        /** ISO-8601 duration like PT2H25M -> "2 h 25 min". */
        fun formatTime(iso: String?): String {
            val m = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?").find(iso ?: "") ?: return ""
            return listOfNotNull(m.groupValues[1].ifEmpty { null }?.let { "$it h" }, m.groupValues[2].ifEmpty { null }?.let { "$it min" }).joinToString(" ")
        }

        fun dbFile(ctx: Context): File = ctx.getDatabasePath("recipes.db")

        fun openIfPresent(ctx: Context): RecipeDb? {
            val f = dbFile(ctx)
            return if (f.exists()) RecipeDb(SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READWRITE)) else null
        }

        /** Copies the user-picked recipes.db into app storage. Call off the main thread. */
        fun importFrom(ctx: Context, uri: Uri, onProgress: (Long) -> Unit) {
            val f = dbFile(ctx); f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open the selected file")
            input.use { i -> tmp.outputStream().use { o ->
                val buf = ByteArray(1 shl 16); var total = 0L; var next = 0L
                while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); total += n
                    if (total >= next) { onProgress(total); next = total + (4L shl 20) } }
            } }
            if (f.exists()) f.delete()
            if (!tmp.renameTo(f)) throw IOException("Could not save the database")
        }
    }
}
