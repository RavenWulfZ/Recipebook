# Recipe Book (Android)
Build with GitHub Actions (see workflow) or open in Android Studio. On first launch the app asks you to pick your recipes.db file.
